<?php

return [
    'k0'=> "All",
    'k1'=> "Architecture",
    'k2'=> "Interior",
    'k3'=> "Religion Project",
];
