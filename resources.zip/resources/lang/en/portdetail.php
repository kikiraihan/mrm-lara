<?php

return [
    'location'=> "Location",
    'year'=> "Year",
    'site'=> "Site Area",
    'flor'=> "Floor Area",
    'tinggi'=> "Height",
    'mitra'=> "Partner in Charge",
    'tipe'=> "Type",
];
