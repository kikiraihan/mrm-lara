<?php

return [
    'home'=> "Home",
    'port'=> "Portfolio",
    'wa'=> "Free Consultation",
];
