<?php

return [
    'k0'=> "Semua",
    'k1'=> "Arsitektur",
    'k2'=> "Interior",
    'k3'=> "Religion Project",
];
