<?php

return [
    'location'=>'Lokasi',
    'year'=>'Tahun',
    'site'=>'Luas situs',
    'flor'=>'Luas lantai',
    'tinggi'=> "Tinggi",
    'mitra'=>'Mitra Penanggung Jawab',
    'tipe'=>'tipe',
];
