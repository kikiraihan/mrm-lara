<?php

return [
    'home'=> "Beranda",
    'port'=> "Portofolio",
    'wa'=> "Konsultasi Gratis",
];
