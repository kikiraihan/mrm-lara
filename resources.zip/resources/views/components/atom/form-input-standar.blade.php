<input 

{!! $attributes->merge([
    'class'=>"shadow text-sm border-none p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-300 placeholder-gray-300",
    'type'=>"text"
    ]) !!}

>