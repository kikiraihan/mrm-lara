<span 
    {!! $attributes->merge([
        'class'=>" px-1 py-0.5 rounded text-xs"
    ]) !!} 
>
    {{$slot}}
</span>